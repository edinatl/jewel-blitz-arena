using UnityEngine;

public enum WeaponType { Bat, Blaster, Bomb }

// A weapon lying in the arena. Walk over it with empty hands to pick it up.
public class WeaponItem : MonoBehaviour
{
    public WeaponType type;
    public float pickupDistance = 1.3f;
    private float bobPhase;

    void Start()
    {
        bobPhase = Random.Range(0f, Mathf.PI * 2f);
    }

    void Update()
    {
        transform.Rotate(Vector3.up, 60f * Time.deltaTime, Space.World);
        Vector3 p = transform.position;
        p.y = 0.9f + Mathf.Sin(Time.time * 2f + bobPhase) * 0.15f;
        transform.position = p;

        var players = GameObject.FindGameObjectsWithTag("Player");
        for (int i = 0; i < players.Length; i++)
        {
            var combat = players[i].GetComponent<PlayerCombat>();
            if (combat == null || combat.HasWeapon) continue;
            float flatDist = Vector2.Distance(
                new Vector2(transform.position.x, transform.position.z),
                new Vector2(players[i].transform.position.x, players[i].transform.position.z));
            if (flatDist <= pickupDistance)
            {
                combat.EquipWeapon(type);
                Destroy(gameObject);
                return;
            }
        }
    }

    public static GameObject Spawn(Vector3 position, WeaponType type)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = "Weapon_" + type.ToString();
        go.transform.position = position;
        var col = go.GetComponent<Collider>();
        if (col != null) Destroy(col);

        var rend = go.GetComponent<Renderer>();
        switch (type)
        {
            case WeaponType.Bat:
                go.transform.localScale = new Vector3(0.18f, 1.0f, 0.18f);
                go.transform.rotation = Quaternion.Euler(0f, 0f, 35f);
                if (rend != null) rend.material.color = new Color(0.65f, 0.4f, 0.15f);
                break;
            case WeaponType.Blaster:
                go.transform.localScale = new Vector3(0.25f, 0.25f, 0.8f);
                if (rend != null) rend.material.color = new Color(0.2f, 0.7f, 0.9f);
                break;
            case WeaponType.Bomb:
                // Cube root, but reads as a chunky bomb crate in prototype form.
                go.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                if (rend != null) rend.material.color = new Color(0.15f, 0.15f, 0.15f);
                break;
        }

        var item = go.AddComponent<WeaponItem>();
        item.type = type;
        return go;
    }
}
