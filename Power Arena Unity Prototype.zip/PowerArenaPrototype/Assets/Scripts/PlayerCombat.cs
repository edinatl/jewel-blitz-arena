using UnityEngine;

// Combat, gems, transformation, and held weapons for one fighter.
public class PlayerCombat : MonoBehaviour
{
    [Header("Tuning")]
    public float lightDamage = 8f;
    public float heavyDamage = 14f;
    public float attackRange = 2.0f;
    public float lightCooldown = 0.35f;
    public float heavyCooldown = 0.8f;

    [Header("State (read-only in play)")]
    public int gems = 0;
    public bool IsTransformed { get; private set; }
    public float TransformTimeLeft { get; private set; }
    public bool HasWeapon { get { return hasWeapon; } }

    public float transformDuration = 12f;
    public int gemsToTransform = 3;

    private bool hasWeapon = false;
    private WeaponType heldWeapon;
    private int weaponUses = 0;
    private GameObject heldVisual;
    private float nextAttackTime = 0f;
    private float damageSinceGemDrop = 0f;

    private Health health;
    private Rigidbody rb;
    private Color baseColor;
    private Renderer bodyRenderer;
    private Light transformLight;
    private Vector3 baseScale;

    void Awake()
    {
        health = GetComponent<Health>();
        rb = GetComponent<Rigidbody>();
        bodyRenderer = GetComponent<Renderer>();
        if (bodyRenderer != null) baseColor = bodyRenderer.material.color;
        baseScale = transform.localScale;
    }

    void Update()
    {
        if (IsTransformed)
        {
            TransformTimeLeft -= Time.deltaTime;
            if (TransformTimeLeft <= 0f) EndTransform();
        }
    }

    // --- Attacks ------------------------------------------------------------

    public void TryLightAttack()
    {
        if (health.IsKO || Time.time < nextAttackTime) return;
        if (hasWeapon) { UseWeapon(); return; }
        nextAttackTime = Time.time + lightCooldown;
        MeleeHit(IsTransformed ? lightDamage * 2f : lightDamage,
                 IsTransformed ? attackRange + 0.6f : attackRange, 6f);
    }

    public void TryHeavyAttack()
    {
        if (health.IsKO || Time.time < nextAttackTime) return;

        if (IsTransformed)
        {
            // Transformed special: big energy wave straight ahead.
            nextAttackTime = Time.time + 0.6f;
            Vector3 origin = transform.position + Vector3.up * 1.0f + transform.forward * 1.0f;
            Projectile.Fire(gameObject, origin, transform.forward, 16f, 20f, 0.6f,
                            new Color(1f, 0.8f, 0.2f), false, 0f);
            return;
        }

        if (hasWeapon) { UseWeapon(); return; }
        nextAttackTime = Time.time + heavyCooldown;
        MeleeHit(heavyDamage, attackRange, 10f);
    }

    void MeleeHit(float damage, float range, float knockback)
    {
        var players = GameObject.FindGameObjectsWithTag("Player");
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] == gameObject) continue;
            Vector3 toOther = players[i].transform.position - transform.position;
            float dist = new Vector2(toOther.x, toOther.z).magnitude;
            if (dist > range) continue;
            Vector3 flat = toOther; flat.y = 0f;
            if (Vector3.Dot(transform.forward, flat.normalized) < 0.35f) continue; // must be facing them

            var otherHealth = players[i].GetComponent<Health>();
            var otherCombat = players[i].GetComponent<PlayerCombat>();
            if (otherHealth != null) otherHealth.TakeDamage(damage);
            if (otherCombat != null)
            {
                Vector3 dir = flat.normalized; dir.y = 0.35f;
                otherCombat.ApplyKnockback(dir, knockback);
                otherCombat.RegisterHitTaken(damage, transform.position);
            }
        }
    }

    public void ApplyKnockback(Vector3 direction, float force)
    {
        if (rb == null) return;
        Vector3 v = rb.velocity;
        rb.velocity = new Vector3(direction.x * force, Mathf.Max(v.y, direction.y * force), direction.z * force);
    }

    // Getting hit can shake a gem loose — the Power Stone scramble.
    void RegisterHitTaken(float damage, Vector3 attackerPos)
    {
        damageSinceGemDrop += damage;
        if (gems > 0 && !IsTransformed && damageSinceGemDrop >= 25f)
        {
            damageSinceGemDrop = 0f;
            gems--;
            Vector3 dropPos = transform.position + new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f));
            dropPos.y = 1.0f;
            PowerGem.Spawn(dropPos);
        }
    }

    // --- Gems + transformation ----------------------------------------------

    public void AddGem()
    {
        if (IsTransformed) return;
        gems++;
        if (gems >= gemsToTransform) StartTransform();
    }

    void StartTransform()
    {
        gems = 0;
        IsTransformed = true;
        TransformTimeLeft = transformDuration;
        transform.localScale = baseScale * 1.3f;
        if (bodyRenderer != null) bodyRenderer.material.color = new Color(1f, 0.8f, 0.15f); // gold
        transformLight = gameObject.AddComponent<Light>();
        transformLight.type = LightType.Point;
        transformLight.color = new Color(1f, 0.8f, 0.2f);
        transformLight.intensity = 3f;
        transformLight.range = 5f;
    }

    void EndTransform()
    {
        IsTransformed = false;
        TransformTimeLeft = 0f;
        transform.localScale = baseScale;
        if (bodyRenderer != null) bodyRenderer.material.color = baseColor;
        if (transformLight != null) Destroy(transformLight);
    }

    // --- Weapons --------------------------------------------------------------

    public void EquipWeapon(WeaponType type)
    {
        hasWeapon = true;
        heldWeapon = type;
        weaponUses = (type == WeaponType.Bat) ? 3 : (type == WeaponType.Blaster ? 4 : 1);

        if (heldVisual != null) Destroy(heldVisual);
        heldVisual = GameObject.CreatePrimitive(PrimitiveType.Cube);
        heldVisual.name = "Held_" + type.ToString();
        var col = heldVisual.GetComponent<Collider>();
        if (col != null) Destroy(col);
        heldVisual.transform.SetParent(transform);
        var rend = heldVisual.GetComponent<Renderer>();

        switch (type)
        {
            case WeaponType.Bat:
                heldVisual.transform.localPosition = new Vector3(0.6f, 1.2f, 0.3f);
                heldVisual.transform.localScale = new Vector3(0.15f, 0.9f, 0.15f);
                heldVisual.transform.localRotation = Quaternion.Euler(0f, 0f, 40f);
                if (rend != null) rend.material.color = new Color(0.65f, 0.4f, 0.15f);
                break;
            case WeaponType.Blaster:
                heldVisual.transform.localPosition = new Vector3(0.5f, 1.0f, 0.5f);
                heldVisual.transform.localScale = new Vector3(0.22f, 0.22f, 0.7f);
                if (rend != null) rend.material.color = new Color(0.2f, 0.7f, 0.9f);
                break;
            case WeaponType.Bomb:
                heldVisual.transform.localPosition = new Vector3(0.5f, 1.4f, 0.3f);
                heldVisual.transform.localScale = new Vector3(0.45f, 0.45f, 0.45f);
                if (rend != null) rend.material.color = new Color(0.15f, 0.15f, 0.15f);
                break;
        }
    }

    void UseWeapon()
    {
        Vector3 origin = transform.position + Vector3.up * 1.1f + transform.forward * 0.8f;
        switch (heldWeapon)
        {
            case WeaponType.Bat:
                nextAttackTime = Time.time + 0.5f;
                MeleeHit(14f, attackRange + 0.3f, 11f);
                break;
            case WeaponType.Blaster:
                nextAttackTime = Time.time + 0.4f;
                Projectile.Fire(gameObject, origin, transform.forward, 20f, 10f, 0.25f,
                                new Color(0.3f, 0.85f, 1f), false, 0f);
                break;
            case WeaponType.Bomb:
                nextAttackTime = Time.time + 0.6f;
                Vector3 lob = transform.forward + Vector3.up * 0.7f;
                Projectile.Fire(gameObject, origin + Vector3.up * 0.4f, lob, 9f, 18f, 0.45f,
                                new Color(0.15f, 0.15f, 0.15f), true, 1f);
                break;
        }

        weaponUses--;
        if (weaponUses <= 0)
        {
            hasWeapon = false;
            if (heldVisual != null) Destroy(heldVisual);
            heldVisual = null;
        }
    }
}
