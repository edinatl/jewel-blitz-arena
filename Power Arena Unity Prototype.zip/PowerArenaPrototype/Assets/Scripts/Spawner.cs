using UnityEngine;

// Spawns gems and weapons on timers at random spots inside the arena.
// Everything is created procedurally, so no prefabs need to be wired up.
public class Spawner : MonoBehaviour
{
    public float arenaHalfSize = 7f;

    [Header("Gems")]
    public float gemFirstDelay = 2f;
    public float gemInterval = 6f;
    public int maxGems = 2;

    [Header("Weapons")]
    public float weaponFirstDelay = 5f;
    public float weaponInterval = 8f;
    public int maxWeapons = 2;

    private float gemTimer;
    private float weaponTimer;

    void Start()
    {
        gemTimer = gemFirstDelay;
        weaponTimer = weaponFirstDelay;
    }

    void Update()
    {
        var gm = GameManager.Instance;
        if (gm != null && gm.MatchOver) return;

        gemTimer -= Time.deltaTime;
        if (gemTimer <= 0f)
        {
            gemTimer = gemInterval;
            if (FindObjectsOfType<PowerGem>().Length < maxGems)
                PowerGem.Spawn(RandomPos());
        }

        weaponTimer -= Time.deltaTime;
        if (weaponTimer <= 0f)
        {
            weaponTimer = weaponInterval;
            if (FindObjectsOfType<WeaponItem>().Length < maxWeapons)
            {
                WeaponType t = (WeaponType)Random.Range(0, 3);
                WeaponItem.Spawn(RandomPos(), t);
            }
        }
    }

    Vector3 RandomPos()
    {
        return new Vector3(Random.Range(-arenaHalfSize, arenaHalfSize), 1.0f,
                           Random.Range(-arenaHalfSize, arenaHalfSize));
    }
}
