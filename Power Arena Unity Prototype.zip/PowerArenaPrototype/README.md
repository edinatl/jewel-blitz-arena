# Power Arena — Prototype v0.1

An original 4-player-arena-brawler *formula* in miniature, inspired by Power Stone 2.
This build is 2 fighters, 1 arena, local play + a solo bot. No Capcom assets, names, or characters.

## Get it playing (3 steps)

1. **Add the project in Unity Hub** — Open Unity Hub → Add → select this `PowerArenaPrototype` folder.
   - Built for **Unity 2022.3 LTS**. Unity 6 will also open it (let it upgrade).
   - If prompted about input handling, choose **Both** or leave the default — the game uses classic `KeyCode` input.
2. **Build the scene** — Once the editor opens, click the top menu: **Prototype → Build Arena Scene**.
   It creates everything (arena, fighters, camera, spawner, hazard) and saves `Assets/Scenes/Arena.unity`.
3. **Press Play.**

## Controls

| Action | Player 1 (Blue) | Player 2 (Red) |
|---|---|---|
| Move | WASD | Arrow keys |
| Jump | Space | Right Shift |
| Light attack / use weapon | F | . (Period) |
| Heavy attack / transformed special | G | / (Slash) |
| Restart match | R (either player) | R |

**Solo play:** Player 2 starts as an AI bot. If a second human presses *any* Player 2 key,
they take over for the rest of that match.

## How a match works

- **120-second timer.** KO your opponent, or have more health when time runs out.
- **Power Gems (red):** collect **3** to transform for 12 seconds — gold, bigger,
  faster, double-damage light attacks, and a heavy-key energy wave. Getting beaten up
  (25+ damage) shakes one of your un-banked gems loose for anyone to grab.
- **Weapons spawn in the arena** — walk over one to pick it up:
  - **Bat** (brown) — 3 big melee hits
  - **Blaster** (blue) — 4 shots
  - **Bomb** (black) — 1 lobbed throw, area damage + knockback
- **Stage Hazard (purple orb):** patrols the arena and damages/knocks back anyone it touches.
  The stage fights back.
- **Camera:** fixed-angle arena camera that zooms to keep both fighters framed.

## What's in the project

```
Assets/Scripts/
  PlayerController.cs  movement, per-player keys, jump, solo AI + human takeover
  PlayerCombat.cs      melee, weapons, gems, transformation
  Health.cs            health + KO
  PowerGem.cs          collectible gem (procedural, distance pickup)
  WeaponItem.cs        arena weapon pickups: Bat / Blaster / Bomb
  Projectile.cs        blaster shots, bombs (explosive), transformed energy wave
  Spawner.cs           timed gem + weapon spawns
  StageHazard.cs       patrolling hazard orb
  ArenaCamera.cs       framing/zoom arena camera
  GameManager.cs       match timer, KO/winner, restart, HUD (OnGUI — no Canvas setup)
Assets/Editor/
  PrototypeBuilder.cs  menu: Prototype → Build Arena Scene (builds the whole scene)
```

Everything spawns procedurally at runtime — no prefabs to wire up, nothing to drag-and-drop.

## Known prototype shortcuts

- Fighters are capsules, weapons are boxes — placeholder shapes on purpose; feel first, art later.
- No sound yet. No online play yet. Fighters 3–4 not yet added (the systems are written
  player-index based, so adding them is content work, not a rewrite).

## Suggested next steps (in order)

1. Play a few matches — is the core hit/gem/transform loop fun?
2. Tune numbers in the Inspector (damage, gem timing, transform duration are all fields).
3. Then: real character models/animations, sound, a second arena, fighters 3–4,
   and online via Unity Netcode if it still feels good.
